import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

void main() {
  runApp(const TallyCounterApp());
}

class TallyCounterApp extends StatelessWidget {
  const TallyCounterApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Tally Counter',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: Colors.indigo,
        brightness: Brightness.light,
      ),
      darkTheme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: Colors.indigo,
        brightness: Brightness.dark,
      ),
      themeMode: ThemeMode.system,
      home: const TallyCounterPage(),
    );
  }
}

class TallyCounterPage extends StatefulWidget {
  const TallyCounterPage({super.key});

  @override
  State<TallyCounterPage> createState() => _TallyCounterPageState();
}

class _TallyCounterPageState extends State<TallyCounterPage> {
  int _counter = 0;
  int _step = 1;
  final List<int> _history = [];

  void _increment() {
    HapticFeedback.lightImpact();
    setState(() {
      _history.add(_counter);
      _counter += _step;
    });
  }

  void _decrement() {
    HapticFeedback.lightImpact();
    setState(() {
      if (_counter > 0) {
        _history.add(_counter);
        _counter = (_counter - _step < 0) ? 0 : _counter - _step;
      }
    });
  }

  void _undo() {
    if (_history.isNotEmpty) {
      HapticFeedback.selectionClick();
      setState(() {
        _counter = _history.removeLast();
      });
    }
  }

  void _reset() {
    showDialog(
      context: context,
      builder: (BuildContext ctx) {
        return AlertDialog(
          title: const Text('Reset Counter'),
          content: const Text('Are you sure you want to reset the count to 0?'),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(ctx).pop(),
              child: const Text('Cancel'),
            ),
            FilledButton.tonal(
              onPressed: () {
                HapticFeedback.mediumImpact();
                setState(() {
                  _counter = 0;
                  _history.clear();
                });
                Navigator.of(ctx).pop();
              },
              child: const Text('Reset'),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Tally Counter', style: TextStyle(fontWeight: FontWeight.w600)),
        centerTitle: true,
        actions: [
          IconButton(
            icon: const Icon(Icons.undo),
            tooltip: 'Undo',
            onPressed: _history.isNotEmpty ? _undo : null,
          ),
          IconButton(
            icon: const Icon(Icons.refresh),
            tooltip: 'Reset',
            onPressed: _counter > 0 ? _reset : null,
          ),
        ],
      ),
      body: SafeArea(
        child: Column(
          children: [
            const SizedBox(height: 16),
            // Step selector
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Text('Step Size: ', style: TextStyle(fontWeight: FontWeight.w500)),
                  const SizedBox(width: 8),
                  SegmentedButton<int>(
                    segments: const [
                      ButtonSegment(value: 1, label: Text('+1')),
                      ButtonSegment(value: 5, label: Text('+5')),
                      ButtonSegment(value: 10, label: Text('+10')),
                    ],
                    selected: {_step},
                    onSelectionChanged: (newSelection) {
                      setState(() {
                        _step = newSelection.first;
                      });
                    },
                  ),
                ],
              ),
            ),
            const Spacer(),
            // Main clickable counter surface
            GestureDetector(
              onTap: _increment,
              behavior: HitTestBehavior.opaque,
              child: Container(
                width: 260,
                height: 260,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: colorScheme.primaryContainer,
                  boxShadow: [
                    BoxShadow(
                      color: colorScheme.shadow.withOpacity(0.15),
                      blurRadius: 20,
                      offset: const Offset(0, 10),
                    ),
                  ],
                  border: Border.all(
                    color: colorScheme.primary.withOpacity(0.3),
                    width: 4,
                  ),
                ),
                child: Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      FittedBox(
                        fit: BoxFit.scaleDown,
                        child: Text(
                          '$_counter',
                          style: TextStyle(
                            fontSize: 72,
                            fontWeight: FontWeight.bold,
                            color: colorScheme.onPrimaryContainer,
                            fontFeatures: const [FontFeature.tabularFigures()],
                          ),
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        'TAP TO COUNT',
                        style: TextStyle(
                          fontSize: 12,
                          letterSpacing: 1.5,
                          fontWeight: FontWeight.w600,
                          color: colorScheme.onPrimaryContainer.withOpacity(0.7),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            const Spacer(),
            // Action buttons
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 24),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Expanded(
                    child: OutlinedButton.icon(
                      style: OutlinedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(vertical: 16),
                      ),
                      onPressed: _counter > 0 ? _decrement : null,
                      icon: const Icon(Icons.remove),
                      label: Text('-$_step'),
                    ),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: FilledButton.icon(
                      style: FilledButton.styleFrom(
                        padding: const EdgeInsets.symmetric(vertical: 16),
                      ),
                      onPressed: _increment,
                      icon: const Icon(Icons.add),
                      label: Text('+$_step'),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
