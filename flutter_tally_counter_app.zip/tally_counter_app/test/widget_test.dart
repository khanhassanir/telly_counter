import 'package:flutter_test/flutter_test.dart';
import 'package:tally_counter_app/main.dart';

void main() {
  testWidgets('Tally counter smoke test', (WidgetTester tester) async {
    await tester.pumpWidget(const TallyCounterApp());

    // Verify counter starts at 0.
    expect(find.text('0'), findsOneWidget);

    // Tap to increment.
    await tester.tap(find.text('TAP TO COUNT'));
    await tester.pump();

    // Verify counter incremented to 1.
    expect(find.text('1'), findsOneWidget);
  });
}
